from django.shortcuts import render, redirect
import random

def index(request):
    request.session['counter'] = 0
    num = random.randint(1, 100)
    print(num)
    request.session['num'] = num
    return render(request, 'index.html')

def guessed_num(request):
    if int(request.POST['num']) < request.session['num'] - 10:
        context = {
            "low_num": f"{request.POST['num']} is Way Too Low!"
        }
        return render(request, 'low_num.html', context)
    elif int(request.POST['num']) < request.session['num']:
        context = {
            "low_num": f"{request.POST['num']} is Too Low!"
        }
        return render(request, 'low_num.html', context)
    elif int(request.POST['num']) > request.session['num'] + 10:
        context = {
            "high_num": f"{request.POST['num']} is Way Too High!"
        }
        return render(request, 'high_num.html', context)
    elif int(request.POST['num']) > request.session['num']:
        context = {
            "high_num": f"{request.POST['num']} is Too High!"
        }
        return render(request, 'high_num.html', context)
    else:
        context = {
            "correct_num": f"Great Job!!! {request.POST['num']} was the correct number!",
        }
        return render(request, 'correct_num.html', context)

def leader_board(request):
    request.session['counter'] += 1
    count = request.session['counter'] 
    request.session['name'] = request.POST['name']
    context = {
        "name_on_template" : request.session['name'],
        "attempts": f"You attempted {count} times!",
    }
    return render(request, 'leader_board.html', context)